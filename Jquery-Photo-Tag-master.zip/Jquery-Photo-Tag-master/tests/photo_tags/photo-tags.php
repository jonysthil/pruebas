{
	"Image" : [
		{
		"id":150,
		"Tags":[
			{
			"id":200,
			"text":"John Doe",
			"left":250,
			"top":50,
			"url": "person.php?id=200",
			"isDeleteEnable": true
			},
			{
			"id":400,
			"text":"Michael Smith",
			"left":420,
			"top":45,
			"width":120,
			"height":120,
			"isDeleteEnable": true
			},
			{
			"id":500,
			"text":"Peter Parker",
			"left":55,
			"top":40,
			"url": "person.php?id=500",
			"isDeleteEnable": false
			}
		]
		}
	],
	"options":{
		"literals": {
			"removeTag": "Remove tag"
		},
		"tag":{
			"flashAfterCreation": true
		}
	}
}
